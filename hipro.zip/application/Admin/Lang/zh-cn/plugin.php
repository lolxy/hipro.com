<?php
return array(
	"Name" => "名称",
	"TEXT_DOMAIN" => '标识',
	"HOOKS" => '钩子',
	"DESCRIPTION" => '描述',
	"AUTHOR" => '作者',
	"UNINSTALLED" => '未安装',
	"INSTALL" => '安装',
	"UNINSTALL" => ' 卸载',
    "PLUGIN_DISCUSSION" => '插件交流',
    "PLUGIN_DOCUMENT" => '开发文档'
);