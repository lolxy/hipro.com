<?php
return array (
  'PROTAL_ADMINCOACH_INDEX' => '教练管理',
);