<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => '127.0.0.1',
    'DB_NAME' => 'hipro_db',
    'DB_USER' => 'root',
    'DB_PWD' => 'root',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'hi_',
    //密钥
    "AUTHCODE" => 'Nf8MBz4vLABivuSgpU',
    //cookies
    "COOKIE_PREFIX" => 'djOlrv_',
);
