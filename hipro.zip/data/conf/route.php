<?php	return array (
  'member' => 'portal/list/index?id=4',
  'mall' => 'portal/list/index?id=5',
  'curriculum' => 'portal/list/index?id=3',
  'coach' => 'portal/list/index?id=6',
  'news' => 'portal/list/index?id=2',
  'detail/:id\d' => 'portal/article/index',
  'list/:id\d' => 'portal/list/index',
  'about' => 'portal/page/index?id=1',
  'contact' => 'portal/page/index?id=2',
  'map' => 'portal/page/index?id=3',
);