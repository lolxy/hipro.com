<?php

namespace Namespaced2;

class Bar
{
    public static $loaded = true;
}
