<?php

$a = new stdClass();
