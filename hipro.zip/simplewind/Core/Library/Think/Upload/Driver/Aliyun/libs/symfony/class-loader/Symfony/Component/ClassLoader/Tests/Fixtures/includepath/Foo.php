<?php

class Foo
{
}
